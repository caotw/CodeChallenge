[How to run the program]
1. java -jar demo-0.0.1-SNAPSHOT.jar
2. Source code and pom files in source.zip
3. For API 1, POST a json to "localhost:8080/settlement". Sample request and json provided in the zip.
4. For API 2, GET localhost:8080/settlement/{requestID}. Sample request provided. 
5. For Mac and Linux environment, use "chmod 777 *" and directly execute the files or copy the content and paste in terminal. For example run samplePost1 then run sampleGet.

[Assumptions]
1. Assume request parameter values are all valid, therefore does not require input sanitisation. This program merely retrieve and store information but does not modify anything. No rules provided for input validation anyway. For cases like invalid values for amount, it will be handled by Java as NumberFormatException etc.
2. Compile using Java 8 and run on http port 8080. Assume curl is installed in the runtime environment.
3. Only use SSI reference data from appendix.
4. Assume market settlement message can only be created once for one unique tradeId. Not allowed to overwrite when there is an existing market settlement message for the tradeId. However, allow to create messages with different tradeId for same SSI reference data.
5. In real production environment, there will probably be some kind of RDBMS involved but for POC this project use H2 in memory database and preload the SSI data when application started.
6. Did not write many JUnit tests. Instead tested by manually sending requests via curl. JUnit for this project is overkill in my opinion.

